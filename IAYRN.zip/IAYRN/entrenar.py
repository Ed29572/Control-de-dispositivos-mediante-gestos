"""
entrenar.py  -  Paso 2: entrenar la red neuronal y exportarla al ESP32.

Red: 42 entradas -> 32 (ReLU) -> 16 (ReLU) -> 7 salidas (softmax)

Genera:
  nn_pesos.h            pesos para el ESP32 (copiar a la carpeta main/ del proyecto)
  matriz_confusion.png  para el reporte
  curva_perdida.png     para el reporte
"""
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from sklearn.metrics import (ConfusionMatrixDisplay, classification_report,
                             confusion_matrix)
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier

from comun import CARPETA, CLASES, N_ENTRADAS, N_PUNTOS

rng = np.random.default_rng(1)

# ---------- 1) Cargar datos ----------
datos = np.loadtxt(os.path.join(CARPETA, "datos.csv"), delimiter=",")
X, y = datos[:, :N_ENTRADAS], datos[:, N_ENTRADAS].astype(int)
print("Muestras por clase:", {CLASES[c]: int((y == c).sum()) for c in range(len(CLASES))})
if set(y) != set(range(len(CLASES))):
    raise SystemExit("Faltan clases en datos.csv: graba las 7 clases (0 a 6).")

Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, stratify=y, random_state=1)


# ---------- 2) Aumento de datos (solo entrenamiento) ----------
# Giro pequeño (+-10 grados), cambio de tamaño y ruido. NO se espeja la mano,
# porque "pulgar izquierda" se convertiria en "pulgar derecha".
def aumentar(X, y, copias=3):
    Xs, ys = [X], [y]
    for _ in range(copias):
        P = X.reshape(-1, N_PUNTOS, 2).copy()
        ang = np.deg2rad(rng.uniform(-10, 10, size=(len(P), 1)))
        c, s = np.cos(ang), np.sin(ang)
        px = c * P[:, :, 0] - s * P[:, :, 1]
        py = s * P[:, :, 0] + c * P[:, :, 1]
        P = np.stack([px, py], axis=2)
        P *= rng.uniform(0.9, 1.1, size=(len(P), 1, 1))
        P += rng.normal(0, 0.02, P.shape)
        P[:, 0, :] = 0                       # la muñeca siempre es el origen
        Xs.append(P.reshape(len(P), -1))
        ys.append(y)
    return np.vstack(Xs), np.concatenate(ys)


Xtr_a, ytr_a = aumentar(Xtr, ytr)

# ---------- 3) Entrenar ----------
red = MLPClassifier(hidden_layer_sizes=(32, 16), activation="relu",
                    max_iter=2000, early_stopping=True, n_iter_no_change=20,
                    random_state=1)
red.fit(Xtr_a, ytr_a)

# ---------- 4) Evaluar ----------
pred = red.predict(Xte)
print("\nPrecision en prueba: {:.2%}\n".format((pred == yte).mean()))
print(confusion_matrix(yte, pred))
print(classification_report(yte, pred, labels=range(len(CLASES)),
                            target_names=CLASES, zero_division=0))

fig, ax = plt.subplots(figsize=(8, 7))
ConfusionMatrixDisplay.from_predictions(yte, pred, display_labels=CLASES,
                                        xticks_rotation=45, ax=ax, colorbar=False)
plt.tight_layout()
plt.savefig(os.path.join(CARPETA, "matriz_confusion.png"), dpi=150)

plt.figure()
plt.plot(red.loss_curve_)
plt.xlabel("Época")
plt.ylabel("Pérdida")
plt.title("Curva de pérdida del entrenamiento")
plt.tight_layout()
plt.savefig(os.path.join(CARPETA, "curva_perdida.png"), dpi=150)

# ---------- 5) Exportar a C ----------
assert list(red.classes_) == list(range(len(CLASES)))
assert len(red.coefs_) == 3


def num(v):
    # Los pesos de entradas que siempre valen 0 (la muñeca) se van encogiendo
    # durante el entrenamiento hasta ~1e-180: no caben en un float de 32 bits y
    # el compilador del ESP32 lo marca como error. Se exportan como 0 exacto
    # (no cambia nada: esas entradas siempre se multiplican por 0).
    if abs(v) < 1e-30:
        return "0.0f"
    return f"{v:.8e}f"


def c1d(a):
    return "{" + ",".join(num(v) for v in a) + "}"


def c2d(a):
    return "{\n" + ",\n".join(c1d(fila) for fila in a) + "\n}"


W1, W2, W3 = red.coefs_
B1, B2, B3 = red.intercepts_
ruta = os.path.join(CARPETA, "nn_pesos.h")
with open(ruta, "w") as f:
    f.write("/* Generado por entrenar.py - no editar a mano */\n#pragma once\n")
    f.write(f"#define N_IN  {W1.shape[0]}\n#define N_H1  {W1.shape[1]}\n")
    f.write(f"#define N_H2  {W2.shape[1]}\n#define N_OUT {W3.shape[1]}\n")
    f.write(f"static const float W1[N_IN][N_H1] = {c2d(W1)};\n")
    f.write(f"static const float B1[N_H1] = {c1d(B1)};\n")
    f.write(f"static const float W2[N_H1][N_H2] = {c2d(W2)};\n")
    f.write(f"static const float B2[N_H2] = {c1d(B2)};\n")
    f.write(f"static const float W3[N_H2][N_OUT] = {c2d(W3)};\n")
    f.write(f"static const float B3[N_OUT] = {c1d(B3)};\n")
print("\nGenerado:", ruta)
print("Copia nn_pesos.h a la carpeta main/ del proyecto ESP-IDF y vuelve a flashear.")
