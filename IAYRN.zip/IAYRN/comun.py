"""
comun.py  -  Funciones compartidas por recolectar.py, entrenar.py y ejecutar.py

* Detecta la mano con MediaPipe (21 puntos).
* Convierte los puntos en 42 numeros (x, y) que son la entrada de la red neuronal.
* Define el orden de las clases. DEBE coincidir con el enum de main.c (ESP32).
"""
import os
import time
import urllib.request

import cv2
import numpy as np
import mediapipe as mp
from mediapipe.tasks.python import vision, BaseOptions

# Orden de clases (indice = salida de la red). Igual que en main.c
CLASES = [
    "ninguno",           # 0
    "mano abierta",      # 1 -> encender foco
    "puño cerrado",      # 2 -> apagar foco
    "pulgar izquierda",  # 3 -> abrir ventana
    "pulgar derecha",    # 4 -> cerrar ventana
    "índice arriba",     # 5 -> encender ventilador
    "índice abajo",      # 6 -> apagar ventilador
]
N_PUNTOS = 21
N_ENTRADAS = N_PUNTOS * 2          # 42

CARPETA = os.path.dirname(os.path.abspath(__file__))
MODELO = os.path.join(CARPETA, "hand_landmarker.task")
URL_MODELO = ("https://storage.googleapis.com/mediapipe-models/hand_landmarker/"
              "hand_landmarker/float16/1/hand_landmarker.task")

# Conexiones entre los 21 puntos (solo para dibujar la mano)
CONEXIONES = [(0, 1), (1, 2), (2, 3), (3, 4), (0, 5), (5, 6), (6, 7), (7, 8),
              (5, 9), (9, 10), (10, 11), (11, 12), (9, 13), (13, 14), (14, 15),
              (15, 16), (13, 17), (17, 18), (18, 19), (19, 20), (0, 17)]


class Detector:
    """Envuelve el detector de manos de MediaPipe."""

    def __init__(self):
        if not os.path.exists(MODELO):
            print("Descargando modelo de manos de MediaPipe (una sola vez)...")
            urllib.request.urlretrieve(URL_MODELO, MODELO)
        opciones = vision.HandLandmarkerOptions(
            base_options=BaseOptions(model_asset_path=MODELO),
            running_mode=vision.RunningMode.VIDEO,
            num_hands=1,
            min_hand_detection_confidence=0.6,
            min_hand_presence_confidence=0.6,
            min_tracking_confidence=0.6,
        )
        self.det = vision.HandLandmarker.create_from_options(opciones)
        self.t0 = time.monotonic()
        self.ultimo_ts = -1

    def procesar(self, frame_bgr):
        """Devuelve la lista de 21 puntos de la mano, o None si no hay mano."""
        rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
        img = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb)
        ts = int((time.monotonic() - self.t0) * 1000)
        if ts <= self.ultimo_ts:                 # MediaPipe exige tiempos crecientes
            ts = self.ultimo_ts + 1
        self.ultimo_ts = ts
        res = self.det.detect_for_video(img, ts)
        return res.hand_landmarks[0] if res.hand_landmarks else None


def extraer(lm, ancho, alto):
    """
    Convierte los 21 puntos en 42 numeros:
      - origen en la muñeca (punto 0)
      - escala = distancia muñeca -> base del dedo medio (punto 9)
    NO se normaliza la rotacion: la orientacion es lo que distingue
    'pulgar izquierda/derecha' e 'indice arriba/abajo'.
    """
    if lm is None:
        return None
    pts = np.array([[p.x * ancho, p.y * alto] for p in lm], dtype=float)
    pts -= pts[0]
    escala = np.linalg.norm(pts[9])
    if escala < 1e-3:
        return None
    return (pts / escala).flatten().tolist()


def dibujar(frame, lm):
    """Dibuja la mano detectada sobre la imagen."""
    if lm is None:
        return
    alto, ancho = frame.shape[:2]
    p = [(int(q.x * ancho), int(q.y * alto)) for q in lm]
    for a, b in CONEXIONES:
        cv2.line(frame, p[a], p[b], (0, 200, 0), 2)
    for x, y in p:
        cv2.circle(frame, (x, y), 4, (0, 0, 255), -1)
