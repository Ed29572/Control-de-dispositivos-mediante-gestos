"""
recolectar.py  -  Paso 1: grabar tu propio dataset de gestos.

Teclas:
  0-6      elegir la clase a grabar (ver lista en pantalla)
  ESPACIO  iniciar / pausar la grabacion
  ESC      guardar en datos.csv y salir

Cada fila del CSV son 42 numeros (la mano) + la clase. Si lo corres varias
veces, las muestras nuevas se AGREGAN a datos.csv.
La imagen esta en espejo (como un espejo): "izquierda" es hacia la izquierda
de la pantalla.
"""
import csv
import os

import cv2
from comun import CLASES, CARPETA, Detector, extraer, dibujar

ARCHIVO = os.path.join(CARPETA, "datos.csv")

detector = Detector()
cap = cv2.VideoCapture(0)
clase, grabando = 0, False
cuenta = [0] * len(CLASES)
filas = []

while True:
    ok, frame = cap.read()
    if not ok:
        print("No se pudo leer la camara")
        break
    frame = cv2.flip(frame, 1)                    # modo espejo
    alto, ancho = frame.shape[:2]

    lm = detector.procesar(frame)
    f = extraer(lm, ancho, alto)
    dibujar(frame, lm)

    # La clase "ninguno" (0) se graba aunque no haya mano; las demas solo con mano
    if grabando:
        if f is not None:
            filas.append(f + [clase])
            cuenta[clase] += 1

    color = (0, 0, 255) if grabando else (0, 255, 255)
    cv2.putText(frame, f"Clase {clase}: {CLASES[clase]}", (10, 30),
                cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, 2)
    cv2.putText(frame, "GRABANDO" if grabando else "PAUSA (espacio)", (10, 60),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)
    cv2.putText(frame, "muestras: " + " ".join(map(str, cuenta)), (10, alto - 15),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
    cv2.imshow("Recolectar gestos", frame)

    k = cv2.waitKey(1) & 0xFF
    if k == 27:
        break
    elif k == 32:
        grabando = not grabando
    elif ord("0") <= k <= ord("0") + len(CLASES) - 1:
        clase = k - ord("0")

cap.release()
cv2.destroyAllWindows()

if filas:
    with open(ARCHIVO, "a", newline="") as fh:
        csv.writer(fh).writerows(filas)
print(f"Guardadas {len(filas)} muestras en {ARCHIVO}")
print("Muestras por clase:", dict(zip(CLASES, cuenta)))
