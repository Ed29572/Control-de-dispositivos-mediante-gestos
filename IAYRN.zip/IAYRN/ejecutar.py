"""
ejecutar.py  -  Paso 4: camara -> ESP32 (la red neuronal corre en el ESP32).

La PC solo detecta la mano y manda los 42 numeros por USB (15 veces por
segundo). El ESP32 clasifica el gesto con su red neuronal y acciona los
relevadores. Su respuesta se muestra en pantalla.

Antes de correr: cierra el monitor serial de ESP-IDF y ajusta PUERTO.
ESC para salir.
"""
import sys
import time

import cv2
import serial
from comun import Detector, extraer, dibujar

PUERTO = "COM3"            # Linux: /dev/ttyUSB0   Mac: /dev/cu.usbserial-XXXX
BAUD = 115200
PERIODO = 1 / 15           # segundos entre envios

try:
    esp = serial.Serial(PUERTO, BAUD, timeout=0)
except serial.SerialException as e:
    sys.exit(f"No se pudo abrir {PUERTO}: {e}")
time.sleep(2)              # al abrir el puerto el ESP32 se reinicia
esp.reset_input_buffer()

detector = Detector()
cap = cv2.VideoCapture(0)
rx, respuesta, t_envio = "", "(sin respuesta)", 0.0

while True:
    ok, frame = cap.read()
    if not ok:
        print("No se pudo leer la camara")
        break
    frame = cv2.flip(frame, 1)                    # mismo modo espejo que al grabar
    alto, ancho = frame.shape[:2]

    lm = detector.procesar(frame)
    f = extraer(lm, ancho, alto)
    dibujar(frame, lm)

    ahora = time.time()
    if ahora - t_envio >= PERIODO:
        if f is None:
            linea = "N\n"                         # no hay mano
        else:
            linea = ",".join(f"{v:.3f}" for v in f) + "\n"
        esp.write(linea.encode())
        t_envio = ahora

    # leer la respuesta del ESP32 (C:clase P:confianza R:estado de los 4 relevadores)
    if esp.in_waiting:
        rx += esp.read(esp.in_waiting).decode(errors="ignore")
        partes = rx.split("\n")
        if len(partes) > 1:
            respuesta = partes[-2].strip()
            rx = partes[-1]

    cv2.putText(frame, "ESP32: " + respuesta, (10, 30),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
    cv2.putText(frame, "C=clase P=confianza R=foco,ventilador,abrir,cerrar",
                (10, alto - 15), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
    cv2.imshow("Gestos + red neuronal en ESP32", frame)
    if cv2.waitKey(1) & 0xFF == 27:
        break

cap.release()
esp.close()
cv2.destroyAllWindows()
