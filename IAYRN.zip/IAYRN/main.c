/*
 * main.c  -  ESP32 (ESP-IDF)
 *
 * Recibe por UART0 (USB) los 42 numeros de la mano que manda ejecutar.py,
 * ejecuta la red neuronal 42-32-16-7 con los pesos de nn_pesos.h y acciona
 * los relevadores segun el gesto reconocido.
 *
 * Relevadores:  IN1 foco | IN2 ventilador | IN3 ventana abrir | IN4 ventana cerrar
 * Gestos (mismo orden que CLASES en comun.py):
 *   mano abierta -> foco ON          puño cerrado   -> foco OFF
 *   pulgar izq.  -> abrir ventana    pulgar derecha -> cerrar ventana
 *   indice arriba-> ventilador ON    indice abajo   -> ventilador OFF
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "driver/uart.h"
#include "esp_log.h"
#include "nn_pesos.h"

/* ---------------- Configuracion ---------------- */
#define ACTIVE_LEVEL      0      /* 0 = modulo activo en bajo (lo comun); 1 = activo en alto */
#define UMBRAL            0.85f  /* confianza minima de la red para aceptar un gesto */
#define ESTABLE           5      /* lecturas seguidas iguales para aceptar el gesto */
#define VENTANA_MS        5000   /* tiempo maximo que se mueve la ventana por gesto */
#define TIEMPO_MUERTO_MS  300    /* pausa antes de invertir el sentido del motor */

enum { R_FOCO, R_VENTILADOR, R_ABRIR, R_CERRAR, NUM_RELAYS };
static const gpio_num_t relay_pins[NUM_RELAYS] = {16, 17, 18, 19};
static bool relay_state[NUM_RELAYS];

enum { G_NINGUNO, G_MANO_ABIERTA, G_PUNO, G_PULGAR_IZQ, G_PULGAR_DER,
       G_INDICE_ARRIBA, G_INDICE_ABAJO };

/* ---------------- Relevadores ---------------- */
static void relay_set(int i, bool on)
{
    relay_state[i] = on;
    gpio_set_level(relay_pins[i], on ? ACTIVE_LEVEL : !ACTIVE_LEVEL);
}

static void relays_init(void)
{
    for (int i = 0; i < NUM_RELAYS; i++) {
        gpio_reset_pin(relay_pins[i]);
        gpio_set_level(relay_pins[i], !ACTIVE_LEVEL);      /* arrancar apagado */
        gpio_set_direction(relay_pins[i], GPIO_MODE_OUTPUT);
        relay_state[i] = false;
    }
}

/* ---------------- Ventana (2 relevadores, enclavados) ---------------- */
static int ventana_activa = -1;            /* -1 = parada, o R_ABRIR / R_CERRAR */
static TickType_t ventana_fin;

static void ventana_parar(void)
{
    relay_set(R_ABRIR, false);
    relay_set(R_CERRAR, false);
    ventana_activa = -1;
}

static void ventana_mover(int rele)
{
    ventana_parar();                                  /* nunca los dos a la vez */
    vTaskDelay(pdMS_TO_TICKS(TIEMPO_MUERTO_MS));      /* pausa antes de invertir */
    relay_set(rele, true);
    ventana_activa = rele;
    ventana_fin = xTaskGetTickCount() + pdMS_TO_TICKS(VENTANA_MS);
    uart_flush_input(UART_NUM_0);                     /* descartar lo acumulado en la pausa */
}

/* ---------------- Red neuronal ---------------- */
/* NN_BEGIN */
static int predecir(const float *x, float *conf)
{
    float h1[N_H1], h2[N_H2], o[N_OUT];

    for (int j = 0; j < N_H1; j++) {
        float s = B1[j];
        for (int i = 0; i < N_IN; i++) s += x[i] * W1[i][j];
        h1[j] = s > 0 ? s : 0;                        /* ReLU */
    }
    for (int j = 0; j < N_H2; j++) {
        float s = B2[j];
        for (int i = 0; i < N_H1; i++) s += h1[i] * W2[i][j];
        h2[j] = s > 0 ? s : 0;                        /* ReLU */
    }

    float mx = -1e30f;
    for (int k = 0; k < N_OUT; k++) {
        float s = B3[k];
        for (int j = 0; j < N_H2; j++) s += h2[j] * W3[j][k];
        o[k] = s;
        if (s > mx) mx = s;
    }

    float suma = 0;                                   /* softmax */
    for (int k = 0; k < N_OUT; k++) { o[k] = expf(o[k] - mx); suma += o[k]; }

    int mejor = 0;
    for (int k = 0; k < N_OUT; k++) {
        o[k] /= suma;
        if (o[k] > o[mejor]) mejor = k;
    }
    *conf = o[mejor];
    return mejor;
}
/* NN_END */

/* ---------------- Logica de control ---------------- */
static void ejecutar_accion(int g)
{
    switch (g) {
    case G_MANO_ABIERTA:  relay_set(R_FOCO, true);        break;
    case G_PUNO:          relay_set(R_FOCO, false);       break;
    case G_PULGAR_IZQ:    ventana_mover(R_ABRIR);         break;
    case G_PULGAR_DER:    ventana_mover(R_CERRAR);        break;
    case G_INDICE_ARRIBA: relay_set(R_VENTILADOR, true);  break;
    case G_INDICE_ABAJO:  relay_set(R_VENTILADOR, false); break;
    default: break;
    }
}

static int cand = -1, cnt = 0, actual = G_NINGUNO;

static void procesar(const char *s)
{
    float x[N_IN], conf = 1.0f;
    int clase;

    if (s[0] == 'N') {                       /* no hay mano */
        clase = G_NINGUNO;
    } else {
        char *p = (char *)s;
        for (int i = 0; i < N_IN; i++) {
            char *fin;
            x[i] = strtof(p, &fin);
            if (fin == p) return;            /* linea incompleta: ignorar */
            p = fin;
            if (*p == ',') p++;
        }
        clase = predecir(x, &conf);
        if (conf < UMBRAL) clase = -1;       /* gesto dudoso */
    }

    if (clase == cand) { if (cnt < 1000) cnt++; }
    else { cand = clase; cnt = 1; }

    /* Accion solo cuando el gesto es estable y cambio respecto al anterior.
       Volver a "ninguno" (o quitar la mano) lo deja listo para repetir. */
    if (clase >= 0 && cnt == ESTABLE && clase != actual) {
        actual = clase;
        ejecutar_accion(actual);
    }

    char resp[48];
    int n = snprintf(resp, sizeof(resp), "C:%d P:%.2f R:%d%d%d%d\n", clase, conf,
                     relay_state[R_FOCO], relay_state[R_VENTILADOR],
                     relay_state[R_ABRIR], relay_state[R_CERRAR]);
    uart_write_bytes(UART_NUM_0, resp, n);
}

void app_main(void)
{
    esp_log_level_set("*", ESP_LOG_NONE);    /* evita ruido en el UART */
    relays_init();

    uart_config_t cfg = {
        .baud_rate = 115200,
        .data_bits = UART_DATA_8_BITS,
        .parity = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
        .source_clk = UART_SCLK_DEFAULT,
    };
    uart_param_config(UART_NUM_0, &cfg);
    uart_driver_install(UART_NUM_0, 4096, 1024, 0, NULL, 0);

    static char linea[512];
    int n = 0;
    uint8_t c;
    while (1) {
        if (uart_read_bytes(UART_NUM_0, &c, 1, pdMS_TO_TICKS(20)) == 1) {
            if (c == '\n') {
                linea[n] = '\0';
                if (n > 0) procesar(linea);
                n = 0;
            } else if (c != '\r') {
                if (n < (int)sizeof(linea) - 1) linea[n++] = c;
                else n = 0;                  /* desbordamiento: descartar linea */
            }
        }
        /* la ventana se detiene sola al cumplirse el tiempo maximo */
        if (ventana_activa >= 0 && (int32_t)(xTaskGetTickCount() - ventana_fin) >= 0)
            ventana_parar();
    }
}
